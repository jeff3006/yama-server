from fastapi import FastAPI
from pydantic import BaseModel
from transformers import AutoTokenizer, AutoModelForCausalLM, TextGenerationPipeline
import torch

app = FastAPI()

MODEL_PATH = "/workspace/yama_brain/models/Mixtral-8x7B-Instruct-v0.1"

tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH, trust_remote_code=True)
model = AutoModelForCausalLM.from_pretrained(
    MODEL_PATH,
    torch_dtype=torch.float16,
    device_map="auto",
    trust_remote_code=True
)
pipeline = TextGenerationPipeline(model=model, tokenizer=tokenizer, device=0)

class Prompt(BaseModel):
    prompt: str

@app.post("/generate")
async def generate_text(prompt: Prompt):
    output = pipeline(prompt.prompt, max_new_tokens=200, do_sample=True, temperature=0.7)
    return { "response": output[0]['generated_text'] }
